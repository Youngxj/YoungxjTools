var _hmt = _hmt || [];
(function() {
    var hm = document.createElement("script");
    hm.src = "//hm.baidu.com/hm.js?ba4f3e957d4295d4696e0d6287053fcc";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
})();

/*$('#content').append(`
    <a target="_blank" href="https://www.upyun.com" style="float:right">
        <img src="https://www.upyun.com/assets/league/90X45.png">
    </a>
    <a target="_blank" href="http://www.vultr.com/?ref=6875759" style="float:right">
        <img src="https://static.skyx.in/vultr-logo.png?v=1" style="margin-top: 5px;margin-right: 20px;width: 90px;height: 32px;">
    </a>
    <a target="_blank" href="https://portal.qiniu.com/signup?code=3lftkrfdygqxe" style="float:right">
        <img src="https://static.skyx.in/qiniu-logo.jpg" style="margin-top: 2px;margin-right: 20px;width: 90px;height: 32px;">
    </a>
`);*/